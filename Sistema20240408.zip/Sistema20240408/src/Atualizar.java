import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.event.ActionListener;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;

public class Atualizar extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTextField textFieldNome;
	private JTextField textFieldEmail;

	/**
	 * Create the panel.
	 */
	public Atualizar(JFrame principal, int id) {
		Pessoa pessoa = new Pessoa(id);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Atualizar / ID: " + pessoa.getId());
		lblNewLabel.setBounds(10, 11, 430, 14);
		add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Nome:");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setBounds(10, 64, 84, 14);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Email:");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2.setBounds(10, 103, 84, 14);
		add(lblNewLabel_2);
		
		textFieldNome = new JTextField(pessoa.getNome());
		textFieldNome.setBounds(104, 61, 202, 20);
		add(textFieldNome);
		textFieldNome.setColumns(10);
		
		textFieldEmail = new JTextField(pessoa.getEmail());
		textFieldEmail.setBounds(104, 100, 202, 20);
		add(textFieldEmail);
		textFieldEmail.setColumns(10);
		
		JButton btnNewButton = new JButton("Atualizar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pessoa.setNome(textFieldNome.getText());
				pessoa.setEmail(textFieldEmail.getText());
				pessoa.salvar();
				principal.getContentPane().removeAll();
				JPanel panel = new JPanel();
				principal.getContentPane().add(panel, BorderLayout.CENTER);
				principal.getContentPane().revalidate();
				JOptionPane.showMessageDialog(principal,
						"Pessoa atualizada com sucesso!",
						"Mensagem",
						JOptionPane.PLAIN_MESSAGE);
			}
		});
		btnNewButton.setBounds(217, 164, 89, 23);
		add(btnNewButton);

	}
}
