import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;

public class Consultar extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTable table;

	/**
	 * Create the panel.
	 */
	public Consultar(JFrame principal) {
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Consultar");
		lblNewLabel.setBounds(10, 11, 430, 14);
		add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 36, 411, 150);
		add(scrollPane);
		
		String colunas[]= {"ID", "Nome", "Email"};
		DefaultTableModel dtm = new DefaultTableModel(colunas, 0);
		Pessoa p = new Pessoa();
		Pessoa[] pessoas = p.consultar();
		if (pessoas != null) {
			for (int i=0; i<pessoas.length; i++) {
				dtm.addRow(new Object[] {
						pessoas[i].getId(),
						pessoas[i].getNome(),
						pessoas[i].getEmail()
				});
			}
		}
		table = new JTable(dtm);
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("Remover");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (table.getSelectedRow() >= 0) {
					principal.getContentPane().removeAll();
					Remover remover = new Remover(principal, (int)table.getValueAt(table.getSelectedRow(), 0));
					principal.getContentPane().add(remover, BorderLayout.CENTER);
					principal.getContentPane().revalidate();
				} else {
					JOptionPane.showMessageDialog(principal,
							"Selecione uma pessoa!",
							"Mensagem", JOptionPane.PLAIN_MESSAGE);
				}
			}
		});
		btnNewButton.setBounds(332, 197, 89, 23);
		add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Atualizar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (table.getSelectedRow() >= 0) {
					principal.getContentPane().removeAll();
					Atualizar atualizar = new Atualizar(principal, (int)table.getValueAt(table.getSelectedRow(), 0));
					principal.getContentPane().add(atualizar, BorderLayout.CENTER);
					principal.getContentPane().revalidate();
				} else {
					JOptionPane.showMessageDialog(principal,
							"Selecione uma pessoa!",
							"Mensagem", JOptionPane.PLAIN_MESSAGE);
				}
			}
		});
		btnNewButton_1.setBounds(233, 197, 89, 23);
		add(btnNewButton_1);

	}
}
