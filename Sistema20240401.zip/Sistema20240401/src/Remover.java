import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.event.ActionListener;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;

public class Remover extends JPanel {

	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public Remover(JFrame principal, int id) {
		Pessoa pessoa = new Pessoa(id);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Deseja remover essa pessoa?");
		lblNewLabel.setBounds(10, 11, 430, 14);
		add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ID:");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setBounds(37, 45, 72, 14);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Nome:");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2.setBounds(37, 70, 72, 14);
		add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Email:");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_3.setBounds(37, 95, 72, 14);
		add(lblNewLabel_3);
		
		JLabel lblNewLabelID = new JLabel(Integer.toString(pessoa.getId()));
		lblNewLabelID.setBounds(119, 45, 304, 14);
		add(lblNewLabelID);
		
		JLabel lblNewLabelNome = new JLabel(pessoa.getNome());
		lblNewLabelNome.setBounds(119, 70, 304, 14);
		add(lblNewLabelNome);
		
		JLabel lblNewLabelEmail = new JLabel(pessoa.getEmail());
		lblNewLabelEmail.setBounds(119, 95, 304, 14);
		add(lblNewLabelEmail);
		
		JButton btnNewButton = new JButton("Sim");
		btnNewButton.setBounds(119, 120, 89, 23);
		add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Não");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				principal.getContentPane().removeAll();
				JPanel panel = new JPanel();
				principal.getContentPane().add(panel, BorderLayout.CENTER);
				principal.getContentPane().revalidate();
			}
		});
		btnNewButton_1.setBounds(218, 120, 89, 23);
		add(btnNewButton_1);

	}
}
